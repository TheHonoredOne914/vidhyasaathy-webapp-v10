(()=>{const S='http://www.w3.org/2000/svg';
const cloud='M10 40 C 0 40,0 24,14 24 C 14 10,34 6,42 16 C 48 4,72 6,74 20 C 90 18,94 40,78 40 Z';
const D={pencil:'<path d="M4 44 L36 12 L44 20 L12 52 L2 54 Z M32 16 L40 24 M4 44 L12 52"/>',
eraser:'<path d="M8 30 L28 10 L46 28 L26 48 L14 48 Z M18 20 L36 38"/>',
ruler:'<path d="M2 20 L70 4 L74 18 L6 34 Z M14 18 l1 5 M24 16 l1 7 M34 13 l1 5 M44 11 l1 7 M54 9 l1 5"/>',
sharp:'<path d="M8 16 L36 16 L36 40 L8 40 Z M8 24 L36 24"/><circle cx="22" cy="32" r="4"/>',
plane:'<path d="M2 26 L56 4 L40 50 L28 32 Z M28 32 L56 4"/>',
abc:'<path d="M4 30 L10 10 L16 30 M6 24 L14 24 M22 10 L22 30 C 32 30,32 20,22 20 C 30 20,30 10,22 10 M46 12 C 38 8,34 14,34 20 C 34 28,40 32,46 28"/>'};
const sky=document.createElement('div');sky.className='sky';sky.setAttribute('aria-hidden','true');
const add=(html,vb,css,cls,w)=>{const s=document.createElementNS(S,'svg');s.setAttribute('viewBox',vb);s.setAttribute('width',w);s.innerHTML=html;s.setAttribute('class',cls);s.style.cssText=css;sky.appendChild(s)};
[[4,180,70,0],[18,120,95,-40],[33,220,80,-20],[50,140,110,-70],[66,200,90,-30],[84,150,100,-55]].forEach(([t,w,d,dl])=>add(`<path class="cl" d="${cloud}"/>`,'0 0 96 44',`top:${t}%;left:0;animation-duration:${d}s;animation-delay:${dl}s`,'drift',w));
[['pencil',6,12,-20],['eraser',88,22,10],['ruler',4,60,-8],['sharp',92,62,6],['plane',70,8,-12],['abc',20,86,4],['pencil',60,80,30],['plane',40,40,8],['eraser',8,35,-14],['ruler',85,45,12],['sharp',12,72,0],['pencil',90,92,-30],['plane',30,55,10],['abc',75,30,-6]].forEach(([k,l,t,r],i)=>add(`<g class="dd">${D[k]}</g>`,'0 0 76 56',`left:${l}%;top:${t}%;--r:${r}deg;animation-duration:${6+i%4*2}s;animation-delay:${-i}s`,'bob',k=='ruler'?84:56));
add('<path class="dd dash" style="opacity:.35" d="M-20 300 C 300 180,500 420,800 260 S 1300 160,1500 320"/><path class="dd dash" style="opacity:.25" d="M-20 700 C 260 600,600 820,900 660 S 1300 600,1500 720"/>','0 0 1440 900','left:0;top:0;width:100%;height:900px','', '100%');
document.body.prepend(sky);const fit=()=>sky.style.height=document.documentElement.scrollHeight+'px';fit();addEventListener('load',fit);
// icons
const I={student:'<path d="M2 9 L12 4 L22 9 L12 14 Z M6 11 V16 C 9 19,15 19,18 16 V11"/>',teacher:'<rect x="3" y="4" width="18" height="12"/><path d="M8 20 L12 16 L16 20 M7 9 L13 9"/>',parent:'<circle cx="8" cy="7" r="3"/><circle cx="17" cy="9" r="2"/><path d="M2 20 C 3 13,13 13,14 20 M14 20 C 15 15,20 15,21 20"/>',admin:'<path d="M3 20 V9 L12 3 L21 9 V20 Z M9 20 V14 H15 V20"/>',
pencil:'<path d="M4 20 L5 15 L16 4 L20 8 L9 19 Z M14 6 L18 10"/>',key:'<circle cx="7" cy="12" r="4"/><path d="M11 12 H21 M17 12 V16 M20 12 V15"/>',lock:'<rect x="5" y="10" width="14" height="10"/><path d="M8 10 V7 C 8 2,16 2,16 7 V10"/>',mail:'<rect x="3" y="5" width="18" height="14"/><path d="M3 6 L12 13 L21 6"/>',phone:'<rect x="7" y="2" width="10" height="20"/><path d="M11 18 H13"/>',book:'<path d="M3 5 C 7 3,10 4,12 6 C 14 4,17 3,21 5 V19 C 17 17,14 18,12 20 C 10 18,7 17,3 19 Z M12 6 V20"/>',pin:'<path d="M12 21 C 6 14,5 11,5 9 C 5 4,19 4,19 9 C 19 11,18 14,12 21 Z"/><circle cx="12" cy="9" r="2"/>',star:'<path d="M12 3 L14 9 L21 9 L15 13 L17 20 L12 16 L7 20 L9 13 L3 9 L10 9 Z"/>',clock:'<circle cx="12" cy="12" r="9"/><path d="M12 7 V12 L15 14"/>'};
const pick=t=>{t=t.toLowerCase();return /student/.test(t)?'student':/teacher/.test(t)?'teacher':/parent/.test(t)?'parent':/admin|school/.test(t)&&!/code/.test(t)?'admin':/pin|password/.test(t)?'lock':/code/.test(t)?'key':/email/.test(t)?'mail':/phone/.test(t)?'phone':/board|class|subject/.test(t)?'book':/city|address/.test(t)?'pin':/name/.test(t)?'pencil':/sign|gets/.test(t)?'star':'pencil'};
document.querySelectorAll('.tt th,.tt td.p,.fld>span,.tab').forEach(e=>{const t=e.textContent.trim();if(!t)return;e.insertAdjacentHTML('afterbegin',`<svg class="ic" viewBox="0 0 24 24" aria-hidden="true">${I[pick(t)]}</svg>`)});
// reveal
const io=new IntersectionObserver(es=>es.forEach(x=>{if(x.isIntersecting){x.target.classList.add('in');io.unobserve(x.target)}}),{threshold:.12});
document.querySelectorAll('section.s .wrap>*,.stop').forEach(e=>{e.classList.add('rv');io.observe(e)});
if(new URLSearchParams(location.search).has('static'))document.querySelectorAll('.rv').forEach(e=>e.classList.add('in'));
})();
